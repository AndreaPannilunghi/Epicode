create database EsFineModuloSQL1

create table PezzaMadre (
NrPzMadre int
, NomeArticolo varchar(25)
, Altezza int
, Filato varchar(25)
, PesoSecco int
, MetriLineari int
constraint PK_PezzaMadre_NrPzMadre primary key (NrPzMadre))

create table Resina (
NrBatch int
, CodiceResina char(7)
, NomeResina varchar(25)
, Viscosit� int
constraint PK_Resina_NrBatch primary key (NrBatch))


create table Prepreg (
NrPrepreg int
, NomePrepreg varchar(25)
, NrPzMadre int
, NrBatchResina int
, Prezzo money
constraint PK_Prepreg_NrPrepreg primary key (NrPrepreg),
constraint FK_Prepreg_PzMadre_NrPzMadre  
foreign key (NrPzMadre)
references PezzaMadre (NrPzMadre),
constraint FK_Prepreg_Resina_NrBatchResina
foreign key (NrBatchResina)
references Resina (NrBatch))


create table Cliente (
IDCliente int
, NomeCliente varchar (25)
, Continente varchar (25)
constraint PK_Cliente_IDCliente primary key (IDCliente))


create table Ordine (
NrOrdine int
, IDCliente int
, DataOrdine date
constraint PK_Ordine_NrOrdine primary key (NrOrdine)
constraint FK_Ordine_Cliente_IDCliente 
foreign key (IDCliente)
references Cliente (IDCliente))

create table DettagliOrdine (
NrOrdine int
, LineaOrdine int
, NrPrepreg int
, MetriQ int
, Prezzo money
constraint PK_DettagliOrdine_NrOrdine_LineaOrdine primary key (NrOrdine, LineaOrdine)
constraint FK_DettagliOrdine_Prepreg_NrPrepreg 
foreign key (NrPrepreg)
references Prepreg (NrPrepreg))

insert into Cliente
values (1, 'Andrea', 'Europa')
, (2, 'Marco', 'Europa')
, (3, 'Riccardo', 'Europa')
, (4, 'Caterina', 'Europa')
, (5, 'Christian', 'America')
, (6, 'Giuseppe', 'America')
, (7, 'Alessandro', 'America')
, (8, 'Matteo', 'Asia')
, (9, 'Piero', 'Oceania')
, (10, 'Alessia', 'Oceania')

insert into PezzaMadre
values (101, 'GG200T', 125, 'GX', 200, 100)
, (102, 'GA200T', 125, 'GX', 200, 100)
, (103, 'GG245P', 125, 'GX', 245, 200)
, (104, 'GG380T', 125, 'ZH', 380, 90)
, (105, 'VV4100T', 127, 'AX', 410, 90)
, (106, 'GG800T', 125, 'GXS', 800, 80)
, (107, 'GG200T', 127, 'TC', 200, 100)
, (108, 'GG200T', 125, 'HTC', 200, 100)
, (109, 'VV770T', 100, 'ZH', 770, 80)
, (110, 'GG200P', 125, 'HTC', 245, 200)

insert into Resina
values (1001, '00X1120', 'X1-120', 150)
, (1002, '00E3150', 'E3-150', 180)
, (1003, '0E3150N', 'E3-150N', 190)
, (1004, 'E3150N2', 'E3-150N2', 190)
, (1005, 'E6215HW', 'E6-215HW', 40)
, (1006, '00X3170', 'X3-170', 210)
, (1007, '00X4140', 'X4-140', 130)
, (1008, '00X4160', 'X4-160', 80)
, (1009, '00R2150', 'R2-150', 130)
, (1010, '00E9150', 'E9-150', 160)

insert into Prepreg 
values (9001, 'GG200TX1120', 101, 1001, 2100) 
, (9002, 'GA200TX1120', 102, 1001, 1800) 
, (9003, 'GG380TX1120', 104, 1001, 1400) 
, (9004, 'GG200TX4160', 101, 1008, 2100) 
, (9005, 'GG200TX4140', 101, 1007, 2000) 
, (9006, 'GG245PR2150', 103, 1009, 4100) 
, (9007, 'GG800TX1120', 106, 1001, 2600) 
, (9008, 'VV410TE3150N', 105, 1003, 3000) 
, (9009, 'VV770E3150N', 109, 1003, 2850) 
, (9010, 'GG200PE3150N2', 110, 1004, 4100) 

insert into Ordine
values (801, 1, '2023-03-16')
, (802, 1, '2023-05-10')
, (803, 2, '2023-03-19')
, (804, 3, '2023-04-03')
, (805, 4, '2023-03-12')
, (806, 5, '2023-01-15')
, (807, 5, '2023-06-10')
, (808, 6, '2023-05-23')
, (809, 7, '2023-04-29')
, (810, 10, '2023-02-25')

insert into DettagliOrdine
values (801, 1, 9001, 125, 2100)
, (801, 2, 9007, 125, 2600)
, (801, 3, 9005, 125, 2000)
, (802, 1, 9001, 125, 2100)
, (803, 1, 9002, 125, 1800)
, (804, 1, 9004, 125, 2100)
, (804, 2, 9006, 125, 4100)
, (805, 1, 9001, 125, 2100)
, (806, 1, 9002, 125, 1800)
, (806, 2, 9010, 125, 4100)
, (807, 1, 9001, 125, 2100)
, (808, 1, 9005, 125, 2000)
, (809, 1, 9005, 125, 2000)
, (810, 1, 9004, 125, 2100)
, (810, 2, 9003, 125, 1400)