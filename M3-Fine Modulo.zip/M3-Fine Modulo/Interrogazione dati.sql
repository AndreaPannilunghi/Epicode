-- la vista AP_Prepreg1 rappresenta l'elenco dei prodotti venduti, con rispettive pezze madri e resine, a prescindere dalla quantit�

-- elenco prepreg venduti nel mese di maggio

SELECT distinct p.NrPrepreg, p.NomePrepreg, o.DataOrdine
FROM Prepreg p
INNER JOIN DettagliOrdine d
on p.NrPrepreg = d.NrPrepreg
inner join Ordine o
on d.NrOrdine = o.NrOrdine
where MONTH(o.DataOrdine) = '05' 

-- somma fatturato dei clienti il cui nome inizia per A in ordine crescente

select c.IDCliente, c.NomeCliente, SUM(d.prezzo) as SommaFatturato
from Cliente c
inner join Ordine o
on c.IDCliente = o.IDCliente
inner join DettagliOrdine d
on o.NrOrdine = d.NrOrdine
where c.NomeCliente like 'A%'
group by c.IDCliente, c.NomeCliente
order by SUM(d.prezzo) asc

-- somma fatturato per ogni cliente (che abbia il fatturato maggiore del fattirato medio) e continente (solo fatturati inferiori a 5000)

select c.IDCliente, c.NomeCliente, SUM(d.prezzo) as SommaFatturato
from Cliente c
inner join Ordine o
on c.IDCliente = o.IDCliente
inner join DettagliOrdine d
on o.NrOrdine = d.NrOrdine
group by c.IDCliente, c.NomeCliente
having SUM(d.prezzo) > (
						select AVG(d1.prezzo)
						from Cliente c1
						inner join Ordine o1
						on c1.IDCliente = o1.IDCliente
						inner join DettagliOrdine d1
						on o1.NrOrdine = d1.NrOrdine)

select c.Continente, SUM(d.prezzo) as SommaFatturato
from Cliente c
inner join Ordine o
on c.IDCliente = o.IDCliente
inner join DettagliOrdine d
on o.NrOrdine = d.NrOrdine
group by c.Continente
having SUM(d.prezzo) < 5000

-- visualizzare il nome, il continente e l'ultima data di vendita del cliente 1 

select c.IDCliente, c.NomeCliente, o.DataOrdine
from Cliente c
inner join Ordine o
on c.IDCliente = o.IDCliente
where c.IDCliente = 1 and
o.DataOrdine = (
				select distinct max(o1.DataOrdine)
				from Ordine o1
				where o1.IDCliente = 1)

-- il codice commerciale e il nome della resina utilizzata per pi� prepreg (tra quelli venduti) in ordine di viscosit� e di quelle non utilizzate(sia con join che con query nidificata)

select r.CodiceResina, r.NomeResina, count(*) as QtaPrepregImpregnati, r.Viscosit�
from Resina r
inner join AP_Prepreg1 ap
on r.NrBatch = ap.NrBatchResina
group by r.CodiceResina, r.NomeResina, r.Viscosit�
order by r.Viscosit�

select r.CodiceResina, r.NomeResina, r.Viscosit�
from Resina r
left join AP_Prepreg1 ap
on r.NrBatch = ap.NrBatchResina
where ap.NrBatchResina is null
group by r.CodiceResina, r.NomeResina, r.Viscosit�
order by r.Viscosit�

select r.CodiceResina, r.NomeResina, r.Viscosit�
from Resina r
where r.NrBatch not in (select NrBatchResina
								from AP_Prepreg1)
group by r.CodiceResina, r.NomeResina, r.Viscosit�
order by r.Viscosit�


-- il nr, il nome, altezza e metri della pezza madre e la resina dei tre prepreg pi� venduti e dei tre che hanno generato pi� fatturato

select top (3) ap.NrPrepreg, ap.NomePrepreg, ap.NomeResina, pm.Altezza as HPzMadre, pm.MetriLineari as MTLPzMadre, count(d.LineaOrdine) as PrepregVenduti
      from DettagliOrdine d
	  inner join AP_Prepreg1 ap
	  on d.NrPrepreg = ap.NrPrepreg
	  inner join PezzaMadre pm
	  on ap.NrPzMadre = pm.NrPzMadre 
	  group by ap.NrPrepreg, ap.NomePrepreg, ap.NomeResina, pm.Altezza, pm.MetriLineari

select top (3) ap.NrPrepreg, ap.NomePrepreg, ap.NomeResina, pm.Altezza as HPzMadre, pm.MetriLineari as MTLPzMadre, SUM(d.prezzo)as SommaFatturato
      from DettagliOrdine d
	  inner join AP_Prepreg1 ap
	  on d.NrPrepreg = ap.NrPrepreg
	  inner join PezzaMadre pm
	  on ap.NrPzMadre = pm.NrPzMadre 
	  group by ap.NrPrepreg, ap.NomePrepreg, ap.NomeResina, pm.Altezza, pm.MetriLineari

