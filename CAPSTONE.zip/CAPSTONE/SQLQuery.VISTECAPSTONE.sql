-- Entit� prodotto
CREATE VIEW ViewProduct AS (
SELECT
p.ProductKey
, p.EnglishProductName AS Product
, ps.EnglishProductSubcategoryName AS Subcategory
, pc.EnglishProductCategoryName AS Category
FROM DimProduct p
INNER JOIN DimProductSubcategory ps
ON p.ProductSubcategoryKey = ps.ProductSubcategoryKey 
INNER JOIN DimProductCategory pc 
ON ps.ProductCategoryKey = pc.ProductCategoryKey
)
-- entit� Reseller
CREATE VIEW ViewReseller AS (
SELECT 
r.ResellerKey  
, r.ResellerName AS Reseller
, r.BusinessType
, g.City
, g.StateProvinceName AS StateProvince
, g.EnglishCountryRegionName AS CountryRegion
FROM DimReseller r
INNER JOIN DimGeography g
ON r.GeographyKey = g.GeographyKey
)

-- Entit� salesperson
CREATE VIEW ViewSalesperson AS (	
SELECT
	e.EmployeeKey 
	, CONCAT( e.FirstName, ' ', e.LastName) AS EmployeeName
	, e.Title AS Lev1
	, e.ParentEmployeeKey
	, CONCAT( m.FirstName, ' ', m.LastName) AS ManagerName
	, m.Title AS Lev2
	, CONCAT( d.FirstName, ' ', d.LastName) AS Director
	FROM DimEmployee e
	INNER JOIN DimEmployee m
	ON e.ParentEmployeeKey = m.ParentEmployeeKey
	INNER JOIN DimEmployee d
	ON m.ParentEmployeeKey = d.EmployeeKey
	WHERE e.SalesPersonFlag = 1 OR e.EmployeeKey = 277)


-- Entit� sales
CREATE VIEW ViewSales AS (
SELECT 
	SalesOrderNumber
	, SalesOrderLineNumber
	, OrderDate
	, ProductKey
	, ResellerKey AS CustomerID
	, EmployeeKey
	, OrderQuantity
	, SalesAmount
	, TotalProductCost
	, 'Reseller' AS SalesType
FROM FactResellerSales
UNION ALL
SELECT 
	SalesOrderNumber
	, SalesOrderLineNumber
	, OrderDate
	, ProductKey
	, CustomerKey AS CustomerID
	, null
	, OrderQuantity
	, SalesAmount
	, TotalProductCost
	, 'Internet' AS SalesType
FROM FactInternetSales
) 

